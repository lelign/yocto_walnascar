Создание windows exe файла
http://www.pyinstaller.org/

pip install pyinstaller
pyinstaller burn_soc.py
