import zlib


file_path = 'u-boot.scr'  # Replace with your file path
#file_path = '/home/iru/mac_change_py/u-boot_ref_1.scr'

def calculate_crc32(filename, chunk_size=65536):
    """
    Compute the CRC-32 checksum of the contents of the given file.

    Args:
        filename (str): The path to the file.
        chunk_size (int): The number of bytes to read per chunk (default 64KB).

    Returns:
        int: The unsigned 32-bit CRC-32 checksum.
    """
    checksum = 0
    try:
        with open(filename, "rb") as f:
            while chunk := f.read(chunk_size):
                checksum = zlib.crc32(chunk, checksum)
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return None
    except IOError as e:
        print(f"Error reading file: {e}")
        return None

    # In Python 3, zlib.crc32 always returns an unsigned integer
    # (equivalent to & 0xFFFFFFFF in Python 2).
    return checksum

# Example usage:
file_path = 'u-boot.scr'  # Replace with your file path
crc32_value = calculate_crc32(file_path)

if crc32_value is not None:
    print(f"The CRC32 checksum of '{file_path}' is: {crc32_value}")
    print(f"The CRC32 checksum in hex is: {format(crc32_value, '08x')}")
