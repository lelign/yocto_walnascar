#!/usr/bin/env python3

import random
import mkimage
import sys
import zlib
import os

file_path_ref = 'u-boot_ref_1.scr'
file_path = 'u-boot.scr'  # Replace with your file path
mac_def = '0a:1b:2c:3d:4e:5f'



def calculate_crc32(filename, chunk_size=65536):
    """
    Compute the CRC-32 checksum of the contents of the given file.

    Args:
        filename (str): The path to the file.
        chunk_size (int): The number of bytes to read per chunk (default 64KB).

    Returns:
        int: The unsigned 32-bit CRC-32 checksum.
    """
    checksum = 0
    try:
        with open(filename, "rb") as f:
            while chunk := f.read(chunk_size):
                checksum = zlib.crc32(chunk, checksum)
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return None
    except IOError as e:
        print(f"Error reading file: {e}")
        return None

    # In Python 3, zlib.crc32 always returns an unsigned integer
    # (equivalent to & 0xFFFFFFFF in Python 2).
    return checksum

def get_mac():
    r = input('MAC address [empty for random]: ')
    if(not r):
        r = random.randrange(0, 0xFFFFFF)
        tmp = "%06x" % r
        mac_address = "48:5b:39:"+tmp[0:2]+":"+tmp[2:4]+":"+tmp[4:6]
        random_mac = 1
    else:
        groups = [int(x, 16) for x in r.split(':')]
        for i in range(len(groups)):
                if(groups[-i-1]>255):
                        print("Invalid address")
                        sys.exit()
                profitt_mac[-i-1] = groups[-i-1]
        mac_address = "%02x:%02x:%02x:%02x:%02x:%02x" % \
                (profitt_mac[0], profitt_mac[1], profitt_mac[2], 
                profitt_mac[3], profitt_mac[4], profitt_mac[5])
    return mac_address

def saveen(env, fname):
    '''
    f = open(fname, "w+")
    f.write(env)
    f.close()
    '''
    with open(fname, "+wb") as f:
         f.write(env)
    

'''cp ref to u-boot.scr'''
'''
with open(file_path_ref, 'rb') as f:
     file_ref = f.read()
with open(file_path, 'wb') as f:
     f.write(file_ref)

crc32_value = calculate_crc32(file_path_ref)
if crc32_value is not None:
    print(f"The CRC32 checksum of '{file_path_ref}' is: {crc32_value} \
           hex is: {format(crc32_value, '08x')} size {os.path.getsize(file_path_ref)}")

crc32_value = calculate_crc32(file_path)
if crc32_value is not None:
    print(f"The CRC32 checksum of '{file_path}' is: {crc32_value} \
          hex is: {format(crc32_value, '08x')} size {os.path.getsize(file_path)}")
'''
print("MAC 1")
mac1 = get_mac()
crc32_value = calculate_crc32(file_path)
if crc32_value is not None:
    print(f"The CRC32 checksum before edit '{file_path}' is: {crc32_value} \
          hex is: {format(crc32_value, '08x')} size {os.path.getsize(file_path)}")
with open(file_path, 'rb') as f:
     file_ref = f.read()
with open(file_path, 'wb') as f:
     f.write(file_ref.replace(mac_def.encode('utf-8'), mac1.encode('utf-8')))

crc32_value = calculate_crc32(file_path)
if crc32_value is not None:
    print(f"The CRC32 checksum after edit '{file_path}' is: {crc32_value} \
          hex is: {format(crc32_value, '08x')} size {os.path.getsize(file_path)}")

exit()







#print("MAC 2")
#mac2 = get_mac()

profitt_mac = [0x70, 0xb3, 0xd5, 0x09, 0x10, 0x00]
'''
f = open("template.txt")
env_template = f.read()
f.close()
'''
with open("template.txt", 'r') as f:
     env_template = f.read()


print(f'mac1 {mac1}')
#print(f'mac2 {mac2}')
#d = env_template % (mac1, mac2)
#d = env_template +' ' + str(mac1) + ' ' + str(mac2)
d = env_template.replace('mac1', mac1)
saveen(d, "boot.script")

print(f"Assigned MAC 1 \t {mac1}")
#print(f"Assigned MAC 2 \t {mac2}")
print("Done")

crc32_value = calculate_crc32(file_path)

if crc32_value is not None:
    print(f"Before CRC32 checksum of '{file_path}' is: {crc32_value}")
    print(f"The CRC32 checksum in hex is: {format(crc32_value, '08x')}")



mkimage.mkimage("u-boot.scr", "boot.script")


crc32_value = calculate_crc32(file_path)

if crc32_value is not None:
    print(f"After CRC32 checksum of '{file_path}' is: {crc32_value}")
    print(f"The CRC32 checksum in hex is: {format(crc32_value, '08x')}")
