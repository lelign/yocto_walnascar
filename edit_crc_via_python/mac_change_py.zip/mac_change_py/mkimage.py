from struct import *
import sys
import os.path
import time
import binascii

def mkimage(f_out, f_in):
    MAGIC = 0x27051956
    IMG_NAME_LENGTH = 32

    archs = {'invalid':0, 'alpha':1, 'arm':2, 'x86':3, 'ia64':4, 'm68k':12,
            'microblaze':14, 'mips':5, 'mips64':6, 'nios':13, 'nios2':15,
            'powerpc':7, 'ppc':7, 's390':8, 'sh':9, 'sparc':10,
            'sparc64':11, 'blackfin':16, 'arv32':17, 'st200':18 }

    oss   = {'invalid':0, 'openbsd':1, 'netbsd':2, 'freebsd':3, '4_4bsd':4,
            'linux':5, 'svr4':6, 'esix':7, 'solaris':8, 'irix':9,
            'sco':10, 'dell':11, 'ncr':12, 'lynos':13, 'vxworks':14,
            'psos':15, 'qnx':16, 'u-boot':17, 'rtems':18, 'artos':19,
            'unity':20, 'integrity':21 }

    types = {'invalid':0, 'standalone':1, 'kernel':2, 'ramdisk':3, 'multi':4,
            'firmware':5,'script':6, 'filesystem':7, 'flat_dt':8 }

    comps = {'none':0, 'bzip2':2, 'gzip':1, 'lzma':3 }

    inputsize = os.path.getsize(f_in)
    inputfile = open(f_in, 'rb')

    try:
            outputfile = open(f_out,'wb')

    except IOError:
            print("Error opening output file for writing, aborting")
            sys.exit(1)

    struct = Struct("!IIIIIIIBBBB"+str(IMG_NAME_LENGTH)+"s")
    struct_size = Struct("!LL")

    outputfile.seek(struct.size+struct_size.size)

    inputcrc = 0

    while True:
            inputblock = inputfile.read(4096)
            if not inputblock: break
            inputcrc = binascii.crc32(inputblock, inputcrc)
            outputfile.write(inputblock)

    inputcrc = inputcrc & 0xffffffff

    structdata = struct.pack(MAGIC, 0, int(time.time()), inputsize, 
                    int("0",16), int("0",16), inputcrc, 
                    5, 2, 6, 
                    0, b"")

    headercrc = binascii.crc32(structdata) & 0xFFFFFFFF

    structdata =  struct.pack(MAGIC, headercrc, int(time.time()), inputsize,
                    int("0",16), int("0",16), inputcrc, 
                    5, 2, 6, 
                    0, b"")

    structdata_size =  struct_size.pack(inputsize, 0)

    outputfile.seek(0)
    outputfile.write(structdata)
    outputfile.write(structdata_size)
    outputfile.close()
    inputfile.close()
