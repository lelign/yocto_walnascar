const jsonObject = {
  "name": "Alice",
  "age": 30,
  "city": "New York",
  one_more:{
    "name_1": "Alice_1",
    "age+1": 33,
    "city_1": "New York_1",
  },  
  again_more:{
      "name_2": "Alice_2",
      "age_2": 34,
      "city_2": "New York_2",
      second_more:{
      "name_2": "Alice_3",
      "age_2": 35,
      "city_2": "New York_3"  
      }    
  }  
};

const keys = Object.keys(jsonObject);

console.log(keys)

console.log(jsonObject.name)
console.log(jsonObject.again_more.second_more.name_2)

/*
Object.keys(jsonObject).forEach(key => { 
        console.log(jsonObject[key]); //values 
        console.log(key); //keys 
    })

*/

function get_all_json_keys(json_object, ret_array = []) {
    for (json_key in json_object) {
        if (typeof(json_object[json_key]) === 'object' && !Array.isArray(json_object[json_key])) {
            ret_array.push(json_key);
            get_all_json_keys(json_object[json_key], ret_array);
        } else if (Array.isArray(json_object[json_key])) {
            ret_array.push(json_key);
            first_element = json_object[json_key][0];
            if (typeof(first_element) === 'object') {
                get_all_json_keys(first_element, ret_array);
            }
        } else {
            ret_array.push(json_key);
        }
    }

    return ret_array
}

ret_keys = get_all_json_keys(jsonObject)
console.log('here keys :' + ret_keys )
console.log('here keys type:' + typeof ret_keys )

console.log('{"key0":"value0", "key1":"value1"}'); 

    var jsonObject_ = JSON.parse('{"key0":"value0", "key1":"value1"}')
    Object.keys(jsonObject).forEach(key => { 
        console.log(jsonObject[key]); //values 
        console.log(key + '\n'); //keys 
    })