// Create a new WebSocket object
// Replace 'your_server.com' with your Lighttpd server's domain or IP
// Replace 'websocket_path' with the path configured in Lighttpd (e.g., '/websocket_path')
import { existsSync, copyFile, writeFile, readFile, readFileSync } from 'node:fs';



const ws = new WebSocket('ws://192.168.0.210/app');
//const ws = new WebSocket('ws://localhost/app');



function writeJsonFile(f_name, content){
    writeFile(f_name, JSON.stringify(content, null, 2), (err) => {
        if (err) {
            console.error('\t\tError writing received_messages:', err)
            return
        }
    });
    //console.log('wrote file :' + path.join(c_path, f_name))
}

// Event listener for when the connection is established
ws.onopen = (event) => {
    console.log('WebSocket connection opened:', event);
//    ws.send('Hello from client!'); // Send a message to the server
};

// Event listener for receiving messages from the server
ws.onmessage = (event) => {
    let parsedMessage = ''
    try{
        parsedMessage = JSON.parse(event.data);
        
        writeJsonFile('./pbxmtv508_' + parsedMessage.type, parsedMessage)
        console.log('Wrote file Message from server JSON:', parsedMessage.type);
        
    }
    catch (parseError) {
        console.error('Error onmessage', parseError); 

    }

    
};

// Event listener for errors
ws.onerror = (error) => {
    console.error('WebSocket error:', error);
};

// Event listener for when the connection is closed
ws.onclose = (event) => {
    console.log('WebSocket connection closed:', event);
};

// Function to send messages (example)
function sendMessage(message) {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
    } else {
        console.warn('WebSocket not open. Message not sent.');
    }
}
