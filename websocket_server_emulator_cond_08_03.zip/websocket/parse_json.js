const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const filePath = path.join(__dirname, 'received_on_80_port.json'); // Adjust path as needed
let jsonData;
let receivedData;
let parsedData;



// get config.json
const websocket_app = new WebSocket('ws://192.168.0.210/app'); // Replace with your server address
console.log('UTC :', parseInt(Date.parse('2022-01-03T20:18:05.833Z') / 1000))
websocket_app.onmessage = (event) => {
    receivedData = event.data;
    try {
        parsedData = JSON.parse(receivedData); // Parse the received JSON string
        console.log('Received JSON data:', parsedData);
        // Process the received JSON data
    } catch (error) {
        console.error('Error parsing received data as JSON:', error);
    }

    try {
        //parsedData.jsonData()
        fs.writeFile('./pbxmtv508_json/' + new Date().toISOString().split('.')[+1], JSON.stringify(parsedData, null, 2), err => {
            if (err) {
                console.error('Error writing received_messages:', err)
            }
        });
        console.log("<received_on_80_port>, saved");
    } catch (error) {
        console.error("Error parsing JSON from WebSocket message:", error);
    }
};

// check config.json
try {
    const fileContent = fs.readFileSync('./config.json', 'utf8');
    jsonData = JSON.parse(fileContent); // Parse the content into a JavaScript object
    console.log("parsed config.json")
} catch (error) {
    console.error('Error reading or parsing JSON file:', error);
    // Handle error, e.g., send an error message to the client
}


/*
// get settings.json
const websocket_8081 = new WebSocket('ws://192.168.0.210:8081'); // Replace with your server address

websocket_8081.onmessage = (event) => {
    received_8081_Data = event.data;
    try {
        parsed_8081_Data = JSON.parse(received_8081_Data); // Parse the received JSON string
        console.log('Received JSON data:', parsed_8081_Data);
        // Process the received JSON data
    } catch (error) {
        console.error('Error parsing received data as JSON:', error);
    }

    try {
        fs.writeFile("settings.json", JSON.stringify(parsed_8081_Data, null, 2), err => {
            if (err) {
                console.error('Error writing received_messages:', err)
            }
        });
        console.log("<received_on_80_port>, saved");
    } catch (error) {
        console.error("Error parsing JSON from WebSocket message:", error);
    }
};

// check settings.json
try {
    const fileContent = fs.readFileSync('./settings.json', 'utf8');
    jsonData = JSON.parse(fileContent); // Parse the content into a JavaScript object
    console.log("parsed config.json")
} catch (error) {
    console.error('Error reading or parsing JSON file:', error);
    // Handle error, e.g., send an error message to the client
}

*/