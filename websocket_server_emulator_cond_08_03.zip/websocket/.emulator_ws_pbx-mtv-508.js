    // before start kill lighttpd on 80 port
    // sudo service lighttpd stop
    // start as
    // sudo node emulator_ws_pbx-mtv-508.js <= cause 80 port
    // Node.js v24.4.0
    // refeerence
    const WebSocket = require('ws');
    const fs = require('fs');
    const http = require('http');
    const port_80 = 8080 // for websocket
    const port_81 = 8080 // for http server
    const subdomen = '/app'
    

    /*
        REFERENCE here
    */
    let file_setting = './settings.json'
    if (!fs.existsSync('./settings.json')){
        fs.copyFile('./ref_settings.json', './settings.json', (err) => {
            if (err) {
                console.error('Error reading file:', err);
                exit;
            }
        });
    }
    
    
    let file_configuration = './configuration.json'
    if (!fs.existsSync('./configuration.json')){
        fs.copyFile('./ref_config.json', './configuration.json', (err) => {
            if (err) {
                console.error('Error reading file:', err);
                exit;
            }
        });
    }
    

    function compareAndReplace(sourceObj, targetObj, array) {
    // Example usage: Update jsonFile2 with values from jsonFile1 where they differ
    // compareAndReplace(jsonFile1, jsonFile2);  
        if(typeof(array) == 'object'){
            local_array = array
        }
        for (const key in sourceObj) {            
            //console.log('source key ', key)
            if (Object.prototype.hasOwnProperty.call(sourceObj, key)) {
                // If the key exists in both and is an object, recurse
                if (typeof sourceObj[key] === 'object' && sourceObj[key] !== null &&
                    typeof targetObj[key] === 'object' && targetObj[key] !== null) {
                    local_array.push(sourceObj[key]);    
                    //console.log('if sourceObj[key], targetObj[key]', sourceObj[key], targetObj[key])
                    compareAndReplace(sourceObj[key], targetObj[key]);
                }else if (sourceObj[key] !== targetObj[key]) {
                    // If values are different, replace in targetObj
                    targetObj[key] = sourceObj[key];
                    //console.log('else if targetObj[key]j', targetObj[key])
                }                
            }
        }
        if(targetObj.type){
            console.log('\t0\tdone\t\t' +targetObj.type)
            return [targetObj, local_array]
        }        
    }
    function showChanges(element) {
    // Example usage: Update jsonFile2 with values from jsonFile1 where they differ
    // compareAndReplace(jsonFile1, jsonFile2);  
       
        for (const key in element) {            
            //console.log('source key ', key)
            if (Object.prototype.hasOwnProperty.call(element, key)) {
                // If the key exists in both and is an object, recurse
                if (typeof element[key] === 'object' && element[key] !== null) {                    
                    console.log('showChanges', element[key])
                    showChanges(element[key]);
                }
            }
        }    
    }

    function parseJsonSendAnswer(objectJson, ws) {
        try {
            // Parse the JSON data
            jsonData = JSON.parse(objectJson, ws);   
            ws.send(JSON.stringify(jsonData));
            console.log(' sent to client:\t' + jsonData.type, );
        } catch (parseError) {
            console.error('Error parseJsonSendAnswer objectJson:', parseError);            
        }
    }

    function writeJsonFile(f_name, content){
        fs.writeFile(f_name, JSON.stringify(content, null, 2), (err) => {
            if (err) {
                console.error('\t\tError writing received_messages:', err)
                return
            }
        });
    }


    const server = http.createServer((req, res) => {
        // Handle regular HTTP requests here if needed
        if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Hello from my HTTP emulator WS server!');
        } else {
        res.writeHead(404);
        res.end('Not Found');
        }
    });

    server.listen(port_81, () => {
        console.log('Server ws listening on localhost:' + port_81 + subdomen);
    });


    //let needsUpgade = false
    const wss_http_server = new WebSocket.Server({ server, path: subdomen });
    wss_http_server.on('connection', ws => {
        console.log('Client connected to localhost:'+ port_80 + subdomen);
        let parsedMessage = ''
        let targetObj = ''
    
        // send settings
        setTimeout(() => {            
            fs.readFile(file_setting, 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                    }
                    parseJsonSendAnswer(data, ws);                    
            });
        }, 300);

        // send config
        setTimeout(() => {
            fs.readFile(file_configuration, 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                    }
                    parseJsonSendAnswer(data, ws);                    
            });            
        }, 300);

        ws.on('message', message => {
            try {
                parsedMessage = JSON.parse(message);
                if (parsedMessage.type == 'keepalive'){ // {"status":"alive"}
                    parsedMessage.data = '{"status":"alive"}';
                    //console.log('parsed type',parsedMessage.type );
                    //console.log('parsed data',parsedMessage.data );
                    ws.send(JSON.stringify(parsedMessage));
                    //parseJsonSendAnswer(parsedMessage, ws)

                } else {
                    //console.log(parsedMessage.type + ' <=  message');
                    if(parsedMessage.type == 'reboot'){
                        console.log('\t1\tparsedMessage.type \t'+ parsedMessage)
                        
                            //console.log(parsedMessage.type + ' <= reboot message');
                            //compareAndReplace(parsedMessage, 'reboot')

                        }
                    let split = parsedMessage.type.split('_')                   
                    const preset = ["preset", "solo", "time"]
                    if (split[0] == 'set'){                        
                        if(split[+1] == 'config'){changFile = file_setting};
                        if(preset.includes(split[+1])){changFile = file_configuration};
                        targetObj = JSON.parse(fs.readFileSync(changFile, 'utf8'));
                        typeTargetObj = targetObj.type;
                        let arrChange = [];
                        //arrChange.length
                        //console.log('arrChange.length() :'+ arrChange.length)
                        returnData = compareAndReplace(parsedMessage, targetObj, arrChange)
                        returnObj = returnData[0]
                        returnArrChange = returnData[1]

                        returnObj.type = typeTargetObj
                        writeJsonFile(changFile, returnObj)
                        writeJsonFile(parsedMessage.type + '.json', parsedMessage)

                        console.log('\t1\treturnArrChange \t\t'+ returnArrChange.length + '\n' +
                                    '\t2\tchangFile \t\t'+ changFile + '\n' +
                                    '\t3\tparsedMessage.type \t' + parsedMessage.type + '\n' +
                                    '\t4\ttargetObj.type \t\t'+ targetObj.type + '\n' +
                                    '\t5\treturnObj.type \t\t'+ returnObj.type +'\n' 
                                    );
                        if (returnArrChange.length == 1){
                            console.log("type returnArrChange =1 :" + typeof(returnArrChange))
                            console.log("returnArrChange =1 :" + returnArrChange)
                            showChanges(returnArrChange)
                        }
                    }                    
                }                 
            } catch (parseError) {
            console.error('Error input message:', parseError);
            }
	    });

        ws.on('close', () => {
                console.log('Client disconnected');
            });

        ws.on('error', error => {
            console.error('WebSocket error:', error);
        });
    });


                            /* 

                            targetObj = JSON.parse(fs.readFileSync(file_configuration, 'utf8'));                            
                            typeTargetObj = targetObj.type
                            returnObj = compareAndReplace(parsedMessage, targetObj)
                            returnObj.type = typeTargetObj
                            writeJsonFile(file_configuration, returnObj)
                            */                            

 /*
                            targetObj = JSON.parse(fs.readFileSync(file_setting, 'utf8'));
                            typeTargetObj = targetObj.type
                            returnObj = compareAndReplace(parsedMessage, targetObj)
                            returnObj.type = typeTargetObj
                            writeJsonFile(file_setting, returnObj)
                            */
    /*
                            //console.log(parsedMessage.type + ' <= config message');

                            //console.log('\t\ttype f_t', typeof(file_target));
                            //const read_file = String[file_target];
                            //console.log('type r_f', typeof(file_target));

                            
                            //console.log('\t3\ttargetObj.type before', typeTargetObj);

                            
                            //console.log('\t3\ttargetObj.type after', return_ob.type);
                            

                            

                            fs.writeFile(file_configuration, JSON.stringify(return_ob, null, 2), (err) => {
                                if (err) {
                                    console.error('\t\tError writing received_messages:', err)
                                    return
                                }
                            });
                            

                           

                            fs.writeFile(parsedMessage.type + '.json', JSON.stringify(parsedMessage, null, 2), (err) => {
                                if (err) {
                                    console.error('\t\tError writing received_messages:', err)
                                    return
                                }
                            });
                            */

     /*

                            //console.log('\t1\tsourceObj.type ', parsedMessage.type);
                            console.log('\t2\tfile_target ', file_setting);
                            
                            //console.log('\t\ttype f_t', typeof(file_target));
                            //const read_file = String[file_target];
                            //console.log('type r_f', typeof(file_target));

                            targetObj = JSON.parse(fs.readFileSync(file_setting, 'utf8'));
                            
                            typeTargetObj = targetObj.type
                            console.log('\t3\ttargetObj.type before', typeTargetObj);

                            return_ob = compareAndReplace(parsedMessage, targetObj)
                            console.log('\t3\ttargetObj.type after', return_ob.type);
                            return_ob.type = typeTargetObj

                            fs.writeFile(file_configuration, JSON.stringify(return_ob, null, 2), (err) => {
                                if (err) {
                                    console.error('\t\tError writing received_messages:', err)
                                    return
                                }
                            });

                            fs.writeFile(parsedMessage.type + '.json', JSON.stringify(parsedMessage, null, 2), (err) => {
                                if (err) {
                                    console.error('\t\tError writing received_messages:', err)
                                    return
                                }
                            });
                            */


                            
                            

 //setTimeout(() => {
                    //    compareAndReplace(parsedMessage, targetObj); 
                    //}, 300);  
                      
                    //compareAndReplace(parsedMessage, targetObj)

                //console.log('Received JSON data:', parsedData);                
                //s.writeFile("./answer_ws/"+ new Date().toISOString().split('.')[+1],
                

                /*
                fs.writeFile(parsedMessage.type + '.json', JSON.stringify(parsedMessage, null, 2), (err) => {
                    if (err) {
                        console.error('Error writing received_messages:', err)
                        return
                    }

                    
                    

                    

                                       
                    
                    

                });

                */

                
                
                        
                    //console.log('needs config')

                    //let myObject = compareAndReplace(parsedMessage, parsedTarget)
                    
                    //let parsedTarget = ''
                    //needsUpgade = true;
                    

                    /*

                    fs.readFile(file_configuration, 'utf8', (err, data) => {
                        if (err) {
                            console.error('Error reading file:', err);
                            //ws.send('Error: Could not read file.');
                            return;
                        }
                        
                        //console.log('\t\t', parsedMessage.type, 'needs upgrade',targetObj.type)
                        //let myObject = ''
                        //compareAndReplace(parsedMessage, parsedTarget)
                        //setTimeout(() => {
                        //myObject = compareAndReplace(parsedMessage, parsedTarget)
                        //    //parseJsonSendAnswer(message, ws); 
                        //}, 300);
                        //console.log('my_object', myObject)
                        targetObj = JSON.parse(data)
                        
                    });

                    */




                    
                //console.log('my_object', myObject)
                //compareAndReplace(parsedMessage, parsedTarget)


                
                /*
                

                if ((split[0] == 'set') && ( preset.includes(split[+1]))){
                    console.log('needs preset')
                    fs.readFile(file_setting, 'utf8', (err, data) => {
                        if (err) {
                            console.error('Error reading file:', err);
                            //ws.send('Error: Could not read file.');
                            return;
                        }
                        parsedTarget = JSON.parse(data)
                        compareAndReplace(parsedMessage, parsedTarget)

                    });
                    
                }
                if (split[0] == 'reboot'){
                    console.log('needs reboot')
                }
                */

                
               
            
            
        

        /*

        setTimeout(() => {
            if (needsUpgade){
                console.log('start upgrade', parsedMessage.type, ' ', targetObj.type)
                compareAndReplace(parsedMessage, targetObj);
                needsUpgade = false
            }else{
                console.log('   ??? ')

            }
            */


                     //   compareAndReplace(parsedMessage, targetObj); 
                    //}, 300); 
        

        
        

        

        

        
            


    


            /*
            fs.readFile('./settings.json', 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                    }
                    try {
                        // Parse the JSON data
                        const jsonData = JSON.parse(data);

                        // Send the JSON data as a string to the client
                        ws.send(JSON.stringify(jsonData));
                        console.log('JSON settings sent to client');

                    } catch (parseError) {
                        console.error('Error parsing JSON data:', parseError);
                        ws.send(JSON.stringify({ error: 'Failed to parse JSON data' }));
                    }
            });
            */

                    /*
                    try {
                        // Parse the JSON data
                        const jsonData = JSON.parse(data);
                        console.log(Object.keys(jsonData));

                        // Send the JSON data as a string to the client
                        ws.send(JSON.stringify(jsonData));
                        console.log(file_setting, ' sent to client');

                    } catch (parseError) {
                        console.error('Error parsing JSON data:', parseError);
                        ws.send(JSON.stringify({ error: 'Failed to parse JSON data' }));
                    }
                        */


















    /*
            fs.readFile('./settings.json', 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                    }
                    try {
                        // Parse the JSON data
                        const jsonData = JSON.parse(data);

                        // Send the JSON data as a string to the client
                        ws.send(JSON.stringify(jsonData));
                        console.log('JSON settings sent to client');

                    } catch (parseError) {
                        console.error('Error parsing JSON data:', parseError);
                        ws.send(JSON.stringify({ error: 'Failed to parse JSON data' }));
                    }
            });
            */
        /*
    const m_1 = "./m_1.json";
    const m_2 = "./m_2.json";
    const m_3 = "./m_3.json";
    const m_4 = "./m_4.json";
    const m_5 = "./config.json";
    const m_6 = "./m_6.json";
    const pbx_req_reference = "./pbx_req_reference";
    
    let data={"name": "", "skills": "", "jobtitel": "Entwickler", "res_linkedin": "GwebSearch"};

    console.log( data["jobtitel"] );
    console.log( data.jobtitel );
    */

            /*
        const dataToSend = {
            type: "message",
            sender: "server",
            content: "Hello from the server!"
        };

        const jsonString = JSON.stringify(dataToSend);
        */

    /*
	    // 5 config
        fs.readFile('./config.json', 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            //const jsonString = JSON.stringify(data);
            const jsonString = JSON.stringify(data);
            ws.send(jsonString);
            console.log('sent data from: config.json');
        });

        fs.readFile('./settings.json', 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            //const jsonString = JSON.stringify(data);
            ws.send(JSON.stringify(data));
            console.log('sent data from: settings.json');
        });

            */

    // without http server
    //const wss = new WebSocket.Server({ port: 8080, path: '/app' });
    
    //const wss = new WebSocket.Server({path: '/app' });
    // with server
    //const wss = new WebSocket.Server({ server });
    /*
    const wss_8080_config = new WebSocket.Server({ port: 8080});
    wss_8080_config.on('connection', ws => {
        console.log('Client connected to config 8080');

        // Read the file content & send via ws
      // 1  
    // 5 config
    fs.readFile('./config.json', 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            //const jsonString = JSON.stringify(data);
            ws.send(JSON.stringify(data));
            console.log('sent data from: config.json');
        });

        ws.on('message', message => {
            try {
                parsedData = JSON.parse(message); // Parse the received JSON string
                console.log('Received JSON data:', parsedData);
                fs.writeFile("answ_8080.json"+ 
                    new Date().toISOString().split('.')[+1], JSON.stringify(parsedData, null, 2), err => {
                    if (err) {
                        console.error('Error writing received_messages:', err)
                    }
                });
                console.log("<answ_8080.json>, saved");   
            } catch (error) {
                console.error('Error parsing received data as JSON via 8080');
            } 
 
	    });       
        

        ws.on('close', () => {
                console.log('Client disconnected 8080 config');
            });

        ws.on('error', error => {
            console.error('WebSocket error:', error);
        });
            
    });
    */
  
    /*
    const wss_8081_settings = new WebSocket.Server({ port: 8081});
    wss_8081_settings.on('connection', ws => {
        console.log('Client connected to settings 8081');

        // 5 settings
        fs.readFile('./settings.json', 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            //const jsonString = JSON.stringify(data);
            ws.send(JSON.stringify(data));
            console.log('sent data from: settings.json');
        });


        ws.on('message', message => {
            try {
                parsedData = JSON.parse(message); // Parse the received JSON string
                console.log('Received JSON data:', parsedData);
                fs.writeFile("answ_8081.json", JSON.stringify(parsedData, null, 2), err => {
                    if (err) {
                        console.error('Error writing received_messages:', err)
                    }
                });
                console.log("<answ_8081.json>, saved");       
                
            } catch (error) {
                console.error('Error parsing received data as JSON via 8081:');
            }    
 
	    });       
        

        ws.on('close', () => {
                console.log('Client disconnected 8081 config');
            });

        ws.on('error', error => {
            console.error('WebSocket error:', error);
        });

    });
    */



                /*    
            try {
  
                    
                    fs.writeFile("received_on_80_port", JSON.stringify(message), err => {
                        if (err) {
                            console.error('Error writing received_messages:', err)
                        }
                    });
                    console.log("<received_on_80_port>, saved");
                    // Process the JSON data here
                //}
            } catch (error) {
                //console.error("Error parsing JSON from WebSocket message:", error);
                console.error("Error parsing JSON from WebSocket message:");
                // Handle cases where the message is not valid JSON
            }
            */
    
             /*   
             } else { // 6
                //console.log(`Received message: <keepalive>`);		
                fs.readFile(m_6, 'utf8', (err, data) => {
                if (err) {
                    console.error('Error reading file:', err);
                    ws.send('Error: Could not read file.');
                    return;
                }
                // Send the file content as a WebSocket message
                ws.send(data);
                console.log('Received message: <keepalive> sent <alive> from:', m_6);
                });
            }  
            */ 

    /*
               // Handle incoming messages if needed
            // console.log(message.toString().startsWith('{"type":"keepalive","data":{}}'))
            if (!message.toString().startsWith('{"type":"keepalive","data":{}}')) {
                // "type":"set_config"

                try {
                    //const jsonData = JSON.parse(message.data);
                    if (message.toString().startsWith('{"type":"set_config"')) {

                        fs.writeFile("settings_answ.json", JSON.stringify(message), err => {
                            if (err) {
                                console.error('Error writing received_messages:', err)
                            }
                        });
                        console.log("received <settings_answ.json>, saved");
                        // Process the JSON data here
                    }
                } catch (error) {
                    console.error("Error parsing JSON from WebSocket message:", error);
                    // Handle cases where the message is not valid JSON
                }

                //} 



            } else { // 6
                //console.log(`Received message: <keepalive>`);		
                fs.readFile(m_6, 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        ws.send('Error: Could not read file.');
                        return;
                    }
                    // Send the file content as a WebSocket message
                    ws.send(JSON.stringify(data));
                    console.log('Received message: <keepalive> sent <alive> from:', m_6);
                });
            }
    
    
    */

    /*
            // Read the file content & send via ws
        // 1  
        fs.readFile(m_1, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(JSON.stringify(data));
            console.log('sent data from:',m_1);
        });
	
	    //2

        fs.readFile(m_2, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(data);
            console.log('sent data from:',m_2);
        });

	    // 3
        fs.readFile(m_3, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(JSON.stringify(data));
            console.log('sent data from:',m_3);
        });

	    // 4
        fs.readFile(m_4, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(JSON.stringify(data));
            console.log('sent data from:',m_4);
        });
        */

    /*
        // Read the file content & send via ws
        // 1  
        fs.readFile(m_1, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(data);
            console.log('sent data from:', m_1);
        });

        //2

        fs.readFile(m_2, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(data);
            console.log('sent data from:', m_2);
        });

        // 3
        fs.readFile(m_3, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(data);
            console.log('sent data from:', m_3);
        });

        // 4
        fs.readFile(m_4, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                ws.send('Error: Could not read file.');
                return;
            }
            // Send the file content as a WebSocket message
            ws.send(data);
            console.log('sent data from:', m_4);
        });
        */