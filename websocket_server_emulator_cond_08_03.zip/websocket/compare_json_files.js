
import { readFile, readFileSync } from 'node:fs';

//const ref_settings = './ref_settings.json'
let json_ref = ''
let json_set = ''
readFile('./ref_settings.json', 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                    }
                    json_ref = JSON.parse(data);
                })
            
readFile('./reboot.json', 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err);
                        //ws.send('Error: Could not read file.');
                        return;
                        
                    }
                    json_set = JSON.parse(data);
                })

/**
 * Deep diff between two object, using lodash
 * @param  {Object} base   Object to compare with
 * @param  {Object} object Object compared
 * @return {Object} Return a new object who represent the diff OR Return FALSE if there is no difference
 */
function differenceBetweenObjects (base,object){
    let diff = false;
    if(typeof object == 'object'){
        for(let k in object){
            if(typeof object[k] != 'object'){
                if(base[k] != object[k]){
                    if(diff == false){diff = {};}
                    diff[k] = object[k];
                }
            }
            else{
                let subDiff = differenceBetweenObjects(base[k],object[k]);
                if(subDiff !== false){
                    if(diff == false){diff = {};}
                    diff[k] = subDiff;
                }
            }
        }
    }
    if(typeof base == 'object'){
        for(let k in base){
            if(!object.hasOwnProperty(k)){
                diff[k] = null;
            }
        }
    }
    return diff;
}

const my_diff = differenceBetweenObjects (json_ref,json_set)

console.log('1 my_diff\n' + my_diff + '\n2 type \n' + (typeof my_diff))


/*
const objectDiff = (json_ref, json_set) => _.fromPairs(_.differenceWith(_.toPairs(json_ref), 
    _.toPairs(json_set),
   _.isEqual));
   
console.log('1 objectDiff' + '\n2 ' + (typeof objectDiff) + '\n3 ' + objectDiff)
*/




