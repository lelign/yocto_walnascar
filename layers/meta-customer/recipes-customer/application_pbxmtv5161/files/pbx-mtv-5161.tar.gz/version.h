#define VERSION "SDK version.h  (" __TIME__ ", " __DATE__ ")"
