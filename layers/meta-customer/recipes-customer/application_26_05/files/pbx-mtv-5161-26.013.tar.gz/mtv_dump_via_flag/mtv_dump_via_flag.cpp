/*it's work but can't dump first frame*/
#include <iostream>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <chrono>
#include <thread>
#include <sstream>
#include <iomanip>

// Константы драйвера
#define DRV_NAME "/dev/mtv-overlay"
#define BUFF_SIZE 4149248 // Выровненный размер 1013 страниц

#define STRMEM_MAGIC 'm'
#define STRMEM_IOCTL_LOCK_BUFFER    _IO(STRMEM_MAGIC, 10)
#define STRMEM_IOCTL_UNLOCK_BUFFER  _IO(STRMEM_MAGIC, 11)

// Стандартная таблица инициализации CRC32 (Полином 0xEDB88320)
static const uint32_t crc32_table[256] = {
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
    0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97DCD988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
    0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
    0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
    0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
    0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
    0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
    0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
    0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
    0x7807C1E2, 0x0F00F174, 0x9609A06E, 0xE10E90F8, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
    0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
    0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
    0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
    0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
    0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
    0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
    0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
    0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
    0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
    0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
    0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
    0xD80180E8, 0xAF06B07E, 0x360FE1C4, 0x4108D152, 0xDF6F04EF, 0x88683479, 0x316164C3, 0x46665455,
    0x61065455, 0x160164C3, 0x8F6F3479, 0xF86804EF, 0x666B2048, 0x116C10DE, 0x88654164, 0xF16271F2,
    0x6F06F457, 0x1801C4C1, 0x8108954B, 0xF60EAB5D, 0x6861304E, 0x1F6600D8, 0x866F5162, 0xF16861F4,
    0x510E5455, 0x260964C3, 0xBF003479, 0xC80704EF, 0x5663954C, 0x2164A5DA, 0xB86DF560, 0xCF6AC5F6,
    0x5ED1D457, 0x29D6E4C1, 0xB0DFAF4B, 0xC7D895D3, 0x59B33D1E, 0x2EB40D88, 0xB7BD5C32, 0xC0BA6CAD,
    0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
    0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
    0x10000000, 0x67073096, 0xFE0E612C, 0x890951BA, 0x176DC419, 0x606AF48F, 0xF963A535, 0x8E6495A3,
    0x1EDB8832, 0x69DCB8A4, 0xF0D5E91E, 0x87DCD988, 0x19B64C2B, 0x6EB17CBD, 0xF7B82D07, 0x80BF1D91
};

// Функция расчета CRC32
uint32_t calculate_crc32(const uint8_t *data, size_t length) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; ++i) {
        crc = (crc >> 8) ^ crc32_table[(crc ^ data[i]) & 0xFF];
    }
    return crc ^ 0xFFFFFFFF;
}

// Функция записи дампа в файл
// Модифицированная функция записи дампов с уникальным Timestamp


void write_dump_to_file(const uint8_t *data, size_t length) {
    // 1. Получаем текущее системное время с точностью до миллисекунд
    auto now = std::chrono::system_clock::now();
    auto time_t_now = std::chrono::system_clock::to_time_t(now);
    auto duration = now.time_since_epoch();
    auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count() % 1000;

    // 2. Преобразуем время в читаемый формат (ГГГГММДД_ЧЧММСС)
    std::tm tm_buf;
    localtime_r(&time_t_now, &tm_buf); // Безопасная функция для потоков в Linux

    // 3. Формируем уникальное имя файла с миллисекундами
    std::stringstream filename;
    filename << "/tmp/dump_"
             << std::put_time(&tm_buf, "%Y%m%d_%H%M%S")
             << "_" << std::setw(3) << std::setfill('0') << millis
             << ".data";

    // 4. Записываем данные в новый уникальный файл
    std::string final_path = filename.str();
    std::ofstream outfile(final_path, std::ios::binary);
    
    if (outfile.is_open()) {
        outfile.write(reinterpret_cast<const char*>(data), length);
        outfile.close();
        std::cout << "[DUMP] New frame captured: " << final_path << std::endl;
    } else {
        std::cerr << "[DUMP] Error: Can't create file " << final_path << std::endl;
    }
}

int main() {
    std::cout << "[DUMP] Starting Background Monitor for Arria 10 via flag...\n";

    // 1. Открываем драйвер
    int fd = open(DRV_NAME, O_RDWR);
    if (fd < 0) {
        std::cerr << "Error: Can't open " << DRV_NAME << std::endl;
        return -1;
    }

    // 2. Мапим ту же самую память ядра
    uint8_t *mmap_buffer = (uint8_t *)mmap(NULL, BUFF_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (mmap_buffer == MAP_FAILED) {
        std::cerr << "Error: mmap failed" << std::endl;
        close(fd);
        return -1;
    }

        // Указатель на флаг готовности кадра в конце mmap-буфера утилиты
    volatile uint32_t *frame_ready_flag = reinterpret_cast<volatile uint32_t*>(mmap_buffer + 4149240);
    
    std::cout << "[DUMP] Waiting for atomic frame-ready flags from Qt application...\n";

    while (true) {
        // 1. Ждем, пока Qt-приложение не выставит флаг в 1
        if (*frame_ready_flag == 0) {
            // Микро-пауза в 1 миллисекунду, чтобы освободить ядро процессора ARM
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }

        // 2. Флаг стал равен 1! Кадр гарантированно дорисован до конца.
        // Мгновенно шлем IOCTL блокировки буфера
        if (ioctl(fd, STRMEM_IOCTL_LOCK_BUFFER) == 0) {
            
            // Сбрасываем флаг обратно в 0, чтобы подготовиться к следующему кадру
            *frame_ready_flag = 0;

            // Записываем гарантированно целый, чистый кадр в tmpfs (ОЗУ)
            write_dump_to_file(mmap_buffer, BUFF_SIZE);

            // Отпускаем блокировку для Qt
            ioctl(fd, STRMEM_IOCTL_UNLOCK_BUFFER);
        } else {
            // Если блокировка сорвалась, сбрасываем флаг, чтобы не зациклиться
            *frame_ready_flag = 0;
        }
    }

    // Очистка (в бесконечном цикле недостижимо, но для порядка)
    munmap(mmap_buffer, BUFF_SIZE);
    close(fd);
    return 0;
}
