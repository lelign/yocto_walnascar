have some image with size offset_x offset_y
first draw_overlay
void PbxMtvSystem::draw_overlay(QImage * image, int offset_x, int offset_y)
{
        Q_ASSERT(image->width()+offset_x<=1920);// Данная конкретная строчка проверяет, что правая граница рисуемой или обрабатываемой картинки с учетом её смещения по оси X не выходит за пределы разрешения Full HD (1920 пикселей).
        Q_ASSERT(image->height()+offset_y<=1080);

        offset_x -= offset_x % 2;
        offset_y -= offset_y % 2;

        if(!dei){
                const int height = image->height()/2;
                int width = image->width()/8;
                for(int y=0; y<height; y++){
                        unsigned int buffer_offset = (offset_y/2+y+0)*1920 + offset_x;
                        convert_line(image, y*2+0, width, (uint8_t*)buffer+(buffer_offset)*3);
                }
                for(int y=0; y<height; y++){
                        unsigned int buffer_offset = (offset_y/2+y+540)*1920 + offset_x;
                        convert_line(image, y*2+1, width, (uint8_t*)buffer+(buffer_offset)*3);
                }
        } else {
                const int height = image->height();
                int width = image->width()/8;
                for(int y=0; y<height; y++){
                        unsigned int buffer_offset = (offset_y+y+0)*1920 + offset_x;
                        convert_line(image, y, width, (uint8_t*)buffer+(buffer_offset)*3);
                }
        }
}

after draw_owerlay do overlay_sync

void PbxMtvSystem::overlay_sync()
{
        int f;

        Q_CHECK_PTR(buffer);

        try{
                /*sudo mknod /dev/mtv-overlay c 249 0*/
                f = open("/dev/mtv-overlay", O_WRONLY); // < try it 
                Q_ASSERT(f>0);

                write(f, buffer, video_size);
                
                close(f);                
        }catch (const std::exception& e) {
                qDebug(category) << "Caught exception:" << e.what();
        }catch (...) {
                // Catch any other unknown exceptions
                qDebug(category) << "Caught an unknown exception";
        }

}

my /dev/mtv-overlay in dts:
 overlay@0xFF202880 {
                        compatible = "pfrt,overlay";
                        reg = <0xFF202880 0x0030>;
			interrupts = <0x0 0x28 0x4>;
                }

Код вашего драйвера ядра написан очень грамотно с точки зрения Linux DMA-API. 
Использование функции dma_alloc_coherent в методе probe — это идеальное решение для вашей 
задачи. Она выделяет физически непрерывный и некэшируемый (coherent) 
буфер размером BUFF_SIZE (8 МБ), который идеально подходит как для процессора HPS, 
так и для DMA-контроллера в FPGA (mSGDMA) [5.93 MB].Однако текущая архитектура 
связки Userspace <-> Kernelspace выполняет лишнюю тяжелую операцию, 
которая создает огромную нагрузку на процессор HPS.
Анализ узкого места (Bottleneck)
В функции mtv_write вашего драйвера происходит следующее:
cssize_t mtv_write(struct file *filp, const char __user * buf, size_t count, loff_t *f_pos) {
    ...
    copy_from_user(board->virt, buf, count); // <--- КРИТИЧЕСКИЙ ТОРМОЗ
    return count;
}

Используйте код с осторожностью.
Каждый раз, когда в Qt-приложении вызывается функция overlay_sync(), происходят три 
ресурсоемкие операции:Вызов write() переключает контекст процессора из пространства 
пользователя в ядро.
Функция copy_from_user начинает побайтово копировать 6.2 МБ данных из 
вашего buffer (выделенного через posix_memalign в Qt) в физический когерентный 
буфер ядра board->virt.
Копирование в dma_alloc_coherent память на архитектурах ARMv7 происходит 
медленнее, чем обычный memcpy, так как для этой области памяти отключен внутренний кэш записи
 процессора.
 Процессор тратит колоссальное количество тактов на простое перекладывание 
 байт из одного места оперативной памяти в другое, вместо того чтобы выполнять 
 NEON-оптимизацию.
 Как ускорить архитектуру в 2 раза: 
 Реализация mmap
 Вместо того чтобы выделять память в Qt через posix_memalign, а затем копировать её 
 через write(), нужно заставить ваше Qt-приложение писать YCrCb-данные напрямую в 
 буфер board->virt, который выделило ядро. 
 Для этого в драйвер необходимо добавить поддержку системного вызова mmap.
 Шаг 1. 
 Модификация драйвера ядра (mtv-overlay.c)
 Добавьте функцию mtv_mmap в код драйвера:c#include <linux/mm.h> 
 // Обязательно для remap_pfn_range

int mtv_mmap(struct file *filp, struct vm_area_struct *vma)
{
        struct board_info *board = filp->private_data;
        unsigned long size = vma->vm_end - vma->vm_start;

        if (size > BUFF_SIZE)
                return -EINVAL;

        // Отключаем кэширование этой области памяти для Userspace
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);

        // Мапим физические страницы dma_alloc_coherent в пространство пользователя
        if (remap_pfn_range(vma, vma->vm_start,
                            virt_to_pfn(board->virt),
                            size, vma->vm_page_prot)) {
                pr_err("mtv-overlay: remap_pfn_range failed\n");
                return -EAGAIN;
        }

        return 0;
}

Используйте код с осторожностью.
Зарегистрируйте её в структуре 
file_operations:cstruct file_operations mtv_fops = {
        open:           mtv_open,
        write:          mtv_write, // можно оставить для обратной совместимости
        mmap:           mtv_mmap,  // <--- ДОБАВИТЬ СЮДА
        unlocked_ioctl: mtv_ioctl
};

Используйте код с осторожностью.
Шаг 2. 
Модификация вашего C++/Qt кода приложения
Теперь в классе PbxMtvSystem вам больше не нужно выделять память через 
posix_memalign или malloc. 
Вы инициализируете buffer один раз при старте 
программы (например, в конструкторе):cpp

// Инициализация при старте приложения (например, в PbxMtvSystem::init)
void PbxMtvSystem::init_buffer() {
    int fd = open("/dev/mtv-overlay", O_RDWR);
    if (fd < 0) {
        qFatal("Не удалось открыть устройство для mmap!");
    }

    // Мапим буфер ядра напрямую в указатель приложения
    // Размер берем 8МБ (BUFF_SIZE драйвера), либо строго video_size
    buffer = (char*)mmap(NULL, 1920*1080*3, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd); // Дескриптор можно закрыть, маппинг останется валидным

    if (buffer == MAP_FAILED) {
        qFatal("Ошибка mmap буфера ядра!");
    }
    
    // Адрес автоматически будет идеально выровнен по странице (оканчиваться на 000)!
    qDebug() << "Buffer successfully mapped at:" << (void*)buffer;
}

Используйте код с осторожностью.
Шаг 3. 
Упрощение функций записи и синхронизацииВаша функция draw_overlay остается абсолютно 
без изменений. 
Ваш высокоскоростной NEON-код через функцию convert_line будет писать пиксели 
напрямую в физическую память board->virt ядра. 
Благодаря отключенному кэшу в mmap, данные мгновенно окажутся в RAM.
А функция overlay_sync() превращается в обычный короткий «пинок» для FPGA, 
так как данные уже лежат там, где надо. 
Чтобы драйвер узнал, что пора запускать DMA, вы можете использовать простой ioctl 
или оставить старый write, но передавать туда всего 1 байт (вместо 6 МБ)
 в качестве флага готовности:cpp
 
 void PbxMtvSystem::overlay_sync()
{
    // Данные уже находятся в памяти FPGA благодаря прямому доступу!
    // Просто уведомляем драйвер (и через него прерывание FPGA), что кадр обновлен
    int f = open("/dev/mtv-overlay", O_WRONLY);
    if (f > 0) {
        char kick = 1;
        write(f, &kick, 1); // Передаем всего 1 байт активации вместо 6 Мегабайт!
        close(f);
    }
}

Используйте код с осторожностью.

(В самом драйвере в mtv_write нужно будет добавить проверку: если count == 1, 
    то 
    copy_from_user делать не нужно, а сразу вызывать dma_post(board);).
    Анализ ISR (Прерывания) в вашем драйвереВ коде вашего драйвера заложена 
    циклическая логика отправки дескрипторов:
    
    c
    static irqreturn_t fpga_isr(int irq, void * data) {
    ...
    dma_post(board); // Запуск следующей итерации чтения FPGA
    return IRQ_HANDLED;
}

Используйте код с осторожностью.
Это означает, что FPGA работает в режиме непрерывного закольцованного стриминга 
(постоянно забирает данные из памяти).
Если вы примените подход с mmap, то скорость работы всей системы вырастет драматически: 
процессор HPS полностью освободится от тяжелой операции копирования памяти 
copy_from_user и перестанет греться, а кадры в видеопотоке перестанут 
пропускаться (исчезнет Frame Drop).


