#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/mach/arch.h>
#include <asm/mach/map.h>
#include <linux/fs.h>
#include <linux/dma-mapping.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/of_irq.h>
#include <linux/of_device.h>
#include <linux/of_address.h>
#include <asm/uaccess.h>
#include <linux/cdev.h>
#include <linux/major.h>
#include <asm/io.h>
#include <linux/mm.h>

MODULE_LICENSE("GPL");

#define DRV_NAME "mtv-overlay"

#define OVERLAY_REG_BASE  0xFF202880
#define OVERLAY_REG_SIZE  0x0030

#define BUFF_SIZE (1024*1024*8)

#define DMATS_CONTROL 0x0000
#define DMATS_DESC 0x0020
#define DMATS_RESPONSE 0x0030

#define DMA_DESC_READ 0x00
#define DMA_DESC_WRITE 0x04
#define DMA_DESC_LEN 0x08
#define DMA_DESC_CONTROL 0x0C

#define DMA_STATUS 0
#define DMA_CONTROL 0x04
#define DMA_RESPONSE_FILL 0x0C
#define DMA_IRQ_CLEAR (1<<9)

struct board_info {
        unsigned int mem1_start;
        unsigned int mem1_size;
        int * mem_reg;
        struct device* mtv_device;
        dma_addr_t dma;
        void *virt;
};

static struct class *mtv_class = NULL;
static int mtv_major = 0;
static struct board_info *g_board = NULL; 

int mtv_open(struct inode *inode, struct file *filp);
ssize_t mtv_write(struct file *filp, const char __user * buf, size_t count, loff_t *f_pos);
int mtv_mmap(struct file *filp, struct vm_area_struct *vma);
int mtv_release(struct inode *inode, struct file *filp);
long mtv_ioctl(struct file *filp, unsigned int ioctl_num, unsigned long ioctl_param);

static const struct file_operations mtv_fops = {
        .owner          = THIS_MODULE,
        .open           = mtv_open,
        .write          = mtv_write,
        .mmap           = mtv_mmap,
        .release        = mtv_release,
        .unlocked_ioctl = mtv_ioctl,
};

static void reg_write(struct board_info * board, unsigned int base, unsigned int addr, unsigned int data)
{
        iowrite32(data, board->mem_reg + (base + addr)/4);
}

static void dma_post(struct board_info * board)
{
        int video_size = 1920*1080*3;
        unsigned int fpga_hardware_address = board->dma;

        reg_write(board, DMATS_DESC, DMA_DESC_READ, fpga_hardware_address);
        reg_write(board, DMATS_DESC, DMA_DESC_LEN, video_size);
        reg_write(board, DMATS_DESC, DMA_DESC_CONTROL, 0

                |(1<<31) // go
                |(1<<15) // Early Termination IRQ Enable
                |(1<<14) // Transfer Complete IRQ Enable

                |(1<<9)  // Generate EOP
                |(1<<8)  // Generate SOP
                );
}

int mtv_mmap(struct file *filp, struct vm_area_struct *vma)
{
        struct board_info *board = filp->private_data;
        unsigned long size = vma->vm_end - vma->vm_start;
        unsigned long pfn;

        if (!board || !board->virt)
                return -EFAULT;

        if (size > BUFF_SIZE)
                return -EINVAL;

        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        vma->vm_flags |= VM_SHARED | VM_DONTEXPAND | VM_DONTDUMP;

        pfn = virt_to_pfn(board->virt);

        if (remap_pfn_range(vma, vma->vm_start, pfn, size, vma->vm_page_prot)) {
                return -EAGAIN;
        }

        return 0;
}

static int __init mtv_overlay_init(void)
{
        printk(KERN_ERR "mtv-overlay: STARTING RELIABLE TRIGGER INITIALIZATION\n");

        g_board = kzalloc(sizeof(struct board_info), GFP_KERNEL);
        if (!g_board)
                return -ENOMEM;

        g_board->mem1_start = OVERLAY_REG_BASE;
        g_board->mem1_size = OVERLAY_REG_SIZE;

        if (!request_mem_region(g_board->mem1_start, g_board->mem1_size, DRV_NAME)) {
                printk(KERN_ERR "mtv-overlay: Failed to request mem region 0x%x\n", g_board->mem1_start);
                kfree(g_board);
                return -EBUSY;
        }

        g_board->mem_reg = ioremap(g_board->mem1_start, g_board->mem1_size);
        if (!g_board->mem_reg) {
                printk(KERN_ERR "mtv-overlay: Failed to ioremap registers\n");
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
                return -ENOMEM;
        }

        g_board->virt = dma_alloc_coherent(NULL, BUFF_SIZE, &g_board->dma, GFP_KERNEL | GFP_DMA);
        if (!g_board->virt) {
                printk(KERN_ERR "mtv-overlay: dma_alloc_coherent failed!\n");
                iounmap(g_board->mem_reg);
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
                return -ENOMEM;
        }

        memset(g_board->virt, 0, BUFF_SIZE);

        printk(KERN_ERR "==================================================\n");
        printk(KERN_ERR "mtv-overlay: FPGA MONOLITHIC PHYSICAL: 0x%pad\n", &g_board->dma);
        printk(KERN_ERR "==================================================\n");

        mtv_class = class_create(THIS_MODULE, DRV_NAME);
        if (IS_ERR(mtv_class)) {
                dma_free_coherent(NULL, BUFF_SIZE, g_board->virt, g_board->dma);
                iounmap(g_board->mem_reg);
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
                return PTR_ERR(mtv_class);
        }

        mtv_major = register_chrdev(0, DRV_NAME, &mtv_fops);
        if (mtv_major < 0) {
                class_destroy(mtv_class);
                dma_free_coherent(NULL, BUFF_SIZE, g_board->virt, g_board->dma);
                iounmap(g_board->mem_reg);
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
                return mtv_major;
        }

        g_board->mtv_device = device_create(mtv_class, NULL, MKDEV(mtv_major, 0), NULL, DRV_NAME);
        if (IS_ERR(g_board->mtv_device)) {
                unregister_chrdev(mtv_major, DRV_NAME);
                class_destroy(mtv_class);
                dma_free_coherent(NULL, BUFF_SIZE, g_board->virt, g_board->dma);
                iounmap(g_board->mem_reg);
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
                return PTR_ERR(g_board->mtv_device);
        }

        reg_write(g_board, DMATS_CONTROL, DMA_CONTROL, 0 | (1<<1));
        printk(KERN_ERR "mtv-overlay: INITIALIZATION COMPLETED SUCCESSFULLY!\n");
        return 0;
}

int mtv_open(struct inode *inode, struct file *filp)
{
        if (!g_board)
                return -EFAULT;
        filp->private_data = g_board;
        return 0;
}

/* Любая запись (даже 1 байт пинка) мгновенно взводит кадр в FPGA */
ssize_t mtv_write(struct file *filp, const char __user * buf, size_t count, loff_t *f_pos)
{
        struct board_info * board = filp->private_data;
        if (board) {
                dma_post(board);
        }
        return count;
}

int mtv_release(struct inode *inode, struct file *filp)
{
        return 0;
}

long mtv_ioctl(struct file *filp, unsigned int ioctl_num, unsigned long ioctl_param)
{
        return 0;
}

static void __exit mtv_overlay_exit(void)
{
        if (g_board) {
                if (g_board->mtv_device)
                        device_destroy(mtv_class, MKDEV(mtv_major, 0));
                unregister_chrdev(mtv_major, DRV_NAME);
                if (mtv_class)
                        class_destroy(mtv_class);
                if (g_board->virt)
                        dma_free_coherent(NULL, BUFF_SIZE, g_board->virt, g_board->dma);
                if (g_board->mem_reg)
                        iounmap(g_board->mem_reg);
                release_mem_region(g_board->mem1_start, g_board->mem1_size);
                kfree(g_board);
        }
        printk(KERN_ERR "mtv-overlay: Module exited\n");
}

module_init(mtv_overlay_init);
module_exit(mtv_overlay_exit);
