#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/dma-mapping.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/mod_devicetable.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/cdev.h>
#include <linux/major.h>
#include <linux/mm.h>
#include <linux/device.h>
#include <asm/io.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Altera OpenSource Dev");
MODULE_DESCRIPTION("Modern mSGDMA Video Overlay Driver for Linux 6.12");

#define DRV_NAME "mtv-overlay"
#define BUFF_SIZE (1024*1024*8) /* 8 МБ кадровый буфер */

/* Регистры mSGDMA */
#define DMATS_CONTROL 0x0000
#define DMATS_DESC 0x0020
#define DMA_DESC_READ 0x00
#define DMA_DESC_LEN 0x08
#define DMA_DESC_CONTROL 0x0C

struct board_info {
        void __iomem *mem_reg;
        struct device *mtv_device;
        dma_addr_t dma;
        void *virt;
        struct cdev cdev;
        dev_t devt;
};

static struct class *mtv_class = NULL;

/* Прототипы функций */
static int mtv_open(struct inode *inode, struct file *filp);
static ssize_t mtv_write(struct file *filp, const char __user *buf, size_t count, loff_t *f_pos);
static int mtv_mmap(struct file *filp, struct vm_area_struct *vma);
static int mtv_release(struct inode *inode, struct file *filp);

static const struct file_operations mtv_fops = {
        .owner          = THIS_MODULE,
        .open           = mtv_open,
        .write          = mtv_write,
        .mmap           = mtv_mmap,
        .release        = mtv_release,
};

static void reg_write(struct board_info *board, unsigned int base, unsigned int addr, unsigned int data)
{
        iowrite32(data, board->mem_reg + (base + addr));
}

static void dma_post(struct board_info *board)
{
        int video_size = 1920 * 1080 * 3;
        
        reg_write(board, DMATS_DESC, DMA_DESC_READ, (unsigned int)board->dma);
        reg_write(board, DMATS_DESC, DMA_DESC_LEN, video_size);
        reg_write(board, DMATS_DESC, DMA_DESC_CONTROL, 
                  (1 << 31) | (1 << 15) | (1 << 14) | (1 << 9) | (1 << 8));
}

static int mtv_open(struct inode *inode, struct file *filp)
{
        struct board_info *board = container_of(inode->i_cdev, struct board_info, cdev);
        filp->private_data = board;
        return 0;
}

static ssize_t mtv_write(struct file *filp, const char __user *buf, size_t count, loff_t *f_pos)
{
        struct board_info *board = filp->private_data;
        if (board) {
                dma_post(board); /* Пинок DMA от QTimer из Qt */
        }
        return count;
}

static int mtv_mmap(struct file *filp, struct vm_area_struct *vma)
{
        struct board_info *board = filp->private_data;
        unsigned long size = vma->vm_end - vma->vm_start;

        if (!board || !board->virt)
                return -EFAULT;

        if (size > BUFF_SIZE)
                return -EINVAL;

        /* Настройка флагов для Linux 6.12 */
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        
        /* В современных ядрах используется vm_flags_set вместо прямого ИЛИ */
        vm_flags_set(vma, VM_SHARED | VM_DONTEXPAND | VM_DONTDUMP);

        if (remap_pfn_range(vma, vma->vm_start, virt_to_pfn(board->virt), size, vma->vm_page_prot)) {
                pr_err("mtv-overlay: mmap remap_pfn_range failed\n");
                return -EAGAIN;
        }

        return 0;
}

static int mtv_release(struct inode *inode, struct file *filp)
{
        return 0;
}

/* Современный Probe для Linux 6.12 */
static int mtv_overlay_probe(struct platform_device *pdev)
{
        struct board_info *board;
        struct resource *res;
        int ret;

        dev_info(&pdev->dev, "Modern Probe started for Linux 6.12\n");

        board = devm_kzalloc(&pdev->dev, sizeof(*board), GFP_KERNEL);
        if (!board)
                return -ENOMEM;

        platform_set_drvdata(pdev, board);

        /* Получаем и мапим регистры по новому стандарту 6.x */
        res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
        board->mem_reg = devm_ioremap_resource(&pdev->dev, res);
        if (IS_ERR(board->mem_reg))
                return PTR_ERR(board->mem_reg);

        /* ИСПРАВЛЕНО ДЛЯ ЛИНУКС 6.12: Жесткая принудительная активация DMA-масок */
        ret = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32));
        if (ret) {
                dev_err(&pdev->dev, "Failed to set 32-bit DMA mask\n");
                return ret;
        }

        /* Выделяем непрерывную память, привязывая её к легитимному контексту pdev->dev */
        board->virt = dma_alloc_coherent(&pdev->dev, BUFF_SIZE, &board->dma, GFP_KERNEL);
        if (!board->virt) {
                dev_err(&pdev->dev, "CMA 8MB Memory allocation failed\n");
                return -ENOMEM;
        }
        memset(board->virt, 0, BUFF_SIZE);

        dev_info(&pdev->dev, "==================================================\n");
        dev_info(&pdev->dev, "6.12 FPGA MONOLITHIC PHYSICAL: 0x%pad\n", &board->dma);
        dev_info(&pdev->dev, "==================================================\n");

        /* Динамическое выделение Major/Minor номеров через современный cdev */
        ret = alloc_chrdev_region(&board->devt, 0, 1, DRV_NAME);
        if (ret < 0)
                goto err_free_dma;

        cdev_init(&board->cdev, &mtv_fops);
        board->cdev.owner = THIS_MODULE;
        ret = cdev_add(&board->cdev, board->devt, 1);
        if (ret < 0)
                goto err_unregister;

        /* Создаем файл /dev/mtv-overlay */
        board->mtv_device = device_create(mtv_class, &pdev->dev, board->devt, NULL, DRV_NAME);
        if (IS_ERR(board->mtv_device)) {
                ret = PTR_ERR(board->mtv_device);
                goto err_cdev_del;
        }

        dev_info(&pdev->dev, "Modern initialization completed successfully!\n");
        return 0;

err_cdev_del:
        cdev_del(&board->cdev);
err_unregister:
        unregister_chrdev_region(board->devt, 1);
err_free_dma:
        dma_free_coherent(&pdev->dev, BUFF_SIZE, board->virt, board->dma);
        return ret;
}

/* В ядре Linux 6.12 функция remove ОБЯЗАНА возвращать void, а не int! */
static void mtv_overlay_remove(struct platform_device *pdev)
{
        struct board_info *board = platform_get_drvdata(pdev);

        if (board) {
                device_destroy(mtv_class, board->devt);
                cdev_del(&board->cdev);
                unregister_chrdev_region(board->devt, 1);
                dma_free_coherent(&pdev->dev, BUFF_SIZE, board->virt, board->dma);
        }
        dev_info(&pdev->dev, "Driver removed successfully\n");
}

static const struct of_device_id mtv_overlay_of_match[] = {
        { .compatible = "pfrt,overlay" },
        { /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, mtv_overlay_of_match);

static struct platform_driver mtv_overlay_driver = {
        .probe  = mtv_overlay_probe,
        .remove = mtv_overlay_remove, /* void функция */
        .driver = {
                .name   = DRV_NAME,
                .owner  = THIS_MODULE,
                .of_match_table = mtv_overlay_of_match,
        },
};

static int __init mtv_overlay_init(void)
{
        /* ИСПРАВЛЕНО ДЛЯ ЛИНУКС 6.12: Новый безопасный вызов class_create без макроса THIS_MODULE */
        mtv_class = class_create(DRV_NAME);
        if (IS_ERR(mtv_class))
                return PTR_ERR(mtv_class);

        return platform_driver_register(&mtv_overlay_driver);
}

static void __exit mtv_overlay_exit(void)
{
        platform_driver_unregister(&mtv_overlay_driver);
        if (mtv_class)
                class_destroy(mtv_class);
}

module_init(mtv_overlay_init);
module_exit(mtv_overlay_exit);
