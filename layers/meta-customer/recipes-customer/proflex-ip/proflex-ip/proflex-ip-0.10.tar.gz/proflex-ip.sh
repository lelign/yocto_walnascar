#! /bin/sh
# /etc/init.d/proflex-ip.sh: start the daemon.

name=proflex-ip
binpath=/usr/bin/$name

test -x $binpath || exit 0

# echo 90 > /sys/class/gpio/export
# echo 100 > /proc/sys/vm/dirty_expire_centisecs
# echo 100 > /proc/sys/vm/dirty_writeback_centisecs

log_begin_msg () {
    echo -n $1
}

log_end_msg () {
    echo $1
}

log_success_msg () {
    echo $1
}

case "$1" in
  start)
    log_begin_msg "Starting $name daemon..."
    sleep 1
    start-stop-daemon --start -b --startas $binpath --name $name
    log_end_msg $?
    ;;
  stop)
    log_begin_msg "Stopping $name daemon..."
    start-stop-daemon --stop --signal INT --retry 5 --name $name
    log_end_msg $?
    ;;
  restart)
    log_begin_msg "Restarting $name daemon..."
    start-stop-daemon --stop --signal INT --retry 5 --name $name
    start-stop-daemon --start -b --startas $binpath --name $name
    log_end_msg $?
    ;;
  reload-or-restart)
    if running
    then
	$0 reload
    else
	$0 start
    fi
    ;;
  *)
    log_success_msg "Usage: /etc/init.d/proflex-ip.sh {start|stop|reload|restart|force-reload|reload-or-restart}"
    exit 1
esac

exit 0
