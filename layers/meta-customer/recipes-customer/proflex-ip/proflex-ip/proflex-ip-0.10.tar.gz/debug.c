#include <stdio.h>
#include <stdarg.h>

#include "debug.h"

extern int dflg;

void pmesg(int level, char* format, ...) {
	va_list args;
	
	if (level>dflg)
		return;
	va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
}

void dump(unsigned char * data, int len)
{
        int i;
        
        if (DEBUG_DUMP>dflg)
			return;

        for(i=0; i<len; i++){
                printf("%02x ", data[i]);
                if((i+1)%16==0) printf("\n");
        }
        if(len) printf("\n");
}