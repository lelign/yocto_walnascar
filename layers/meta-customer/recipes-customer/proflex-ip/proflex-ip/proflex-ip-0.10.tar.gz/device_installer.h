#define DEVINST_ID 0x01
#define DEVINST_IP 0x02
#define DEVINST_MAC 0x03

typedef struct devinst_id{
	unsigned char version;
} devinst_id;

typedef struct devinst_ip{
	unsigned char mac[6];
	unsigned char ip[4];
	unsigned char gw[4];
	unsigned char mask[4];
	unsigned char dst_ip[4];
} devinst_ip;

typedef struct devinst_mac{
	unsigned char mac[6];
	unsigned char old_mac[6];
} devinst_mac;

typedef union {
	struct devinst_id id;
	struct devinst_ip ip;
	struct devinst_mac mac;
	char data[30];
}devinst_proto;
