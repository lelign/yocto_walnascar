enum {DEBUG_NONE, DEBUG_STATUS, DEBUG_INFO, DEBUG_DUMP};

extern int dflg;

void pmesg(int level, char* format, ...);
void dump(unsigned char * data, int len);
