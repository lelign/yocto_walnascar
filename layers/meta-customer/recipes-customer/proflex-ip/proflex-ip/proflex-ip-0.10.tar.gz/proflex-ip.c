#include <stdio.h>  
#include <sys/types.h>
#include <ifaddrs.h>
#include <net/if.h>       // if_nametoindex() - нужен для поиска файла DHCP-лизы
#include <netinet/in.h> 
#include <string.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h> 
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include "device_installer.h"
#include "debug.h"

const char * target_iface="eth0";

// Вместо INTERFACES_FILE используем путь к systemd
#define SYSTEMD_NETWORK_FILE "/etc/systemd/network/10-eth0.network"
#define ACCESS_FILE "/var/volatile/proflex-ip-disable"

// Шаблон под новый формат systemd-networkd
const char * config_template = 
"[Match]\n"
"Name=%s\n\n"
"[Network]\n"
"Address=%d.%d.%d.%d/%d\n"
"Gateway=%d.%d.%d.%d\n";

// Дефолтный конфиг: DHCP + гарантированный статический адрес-фолбэк.
//
// Почему не "чистый DHCP=ipv4": если в момент включения устройства в сети
// нет DHCP-сервера (типичная ситуация для изолированной/промышленной сети,
// которую как раз и настраивают через эту утилиту по broadcast), eth0
// остался бы вообще без IPv4-адреса, и устройство стало бы недоступно.
// systemd-networkd поддерживает одновременно статический Address= и
// DHCP=ipv4 в одном .network файле - интерфейс получит оба адреса, если
// DHCP-сервер есть, и хотя бы статический - если его нет.
//
// ClientIdentifier=mac - ОБЯЗАТЕЛЬНО, если на DHCP-сервере есть резервации
// адресов по MAC. По умолчанию systemd-networkd шлёт в DHCP option 61
// (Client Identifier) не MAC, а DUID - идентификатор, привязанный к
// machine-id хоста, а не к интерфейсу. Резервация "выдавать этому MAC
// адрес X" сервером ищется чаще всего именно по option 61, если клиент
// его прислал; DUID туда не попадает, и сервер отдаёт адрес из общего
// пула вместо зарезервированного.
const char * config_default = 
"[Match]\n"
"Name=eth0\n\n"
"[Network]\n"
"DHCP=ipv4\n"
"Address=192.168.0.209/24\n"
"Gateway=192.168.0.1\n\n"
"[DHCPv4]\n"
"ClientIdentifier=mac\n";

#define dst_ip_FILE "/etc/proflex_dst_ip"

// Каталог лиз systemd-networkd: файл внутри называется по числовому
// ifindex интерфейса и содержит ADDRESS=/NETMASK=/ROUTER=/... (см.
// systemd-networkd, sd-dhcp-client - "this is private data, do not parse",
// но формат стабилен уже много лет и используется так во многих проектах).
#define DHCP_LEASE_DIR "/run/systemd/netif/leases"

int dflg;

int netmask_to_prefix(unsigned char *netmask) {
    int prefix = 0;
    for (int i = 0; i < 4; i++) {
        unsigned char byte = netmask[i];
        while (byte) { prefix += byte & 1; byte >>= 1; }
    }
    return prefix;
}

void prefix_to_netmask(int prefix, unsigned char *netmask) {
    if (prefix < 0) prefix = 0;
    if (prefix > 32) prefix = 32;
    
    uint32_t mask = (prefix == 0) ? 0 : (0xFFFFFFFF << (32 - prefix));

    netmask[0] = (mask >> 24) & 0xFF;
    netmask[1] = (mask >> 16) & 0xFF;
    netmask[2] = (mask >> 8) & 0xFF;
    netmask[3] = mask & 0xFF;
}

/**
* Читает актуальную DHCP-лизу интерфейса target_iface из
* /run/systemd/netif/leases/<ifindex> и заполняет netmask/gateway
* реальными значениями, полученными от DHCP-сервера.
*
* Возвращает 1, если удалось прочитать и NETMASK=, и ROUTER= из лизы;
* 0, если интерфейса нет, лиза ещё не получена (например, сразу после
* загрузки, пока DHCP не завершил обмен) или DHCP-сервер не выдал
* нужных полей. Это НЕ ошибка чтения конфига - это нормальное временное
* состояние, вызывающий код должен относиться к нему соответственно
* (не заменять валидный DHCP-конфиг конфигом по умолчанию из-за этого).
**/
int get_dhcp_lease(unsigned char * netmask, unsigned char * gateway)
{
        char path[64];
        char buffer[256];
        FILE * f;
        unsigned int ifindex;
        int a, b, c, d;
        int have_netmask = 0, have_gateway = 0;

        ifindex = if_nametoindex(target_iface);
        if (ifindex == 0)
                return 0; // интерфейса с таким именем сейчас нет

        snprintf(path, sizeof(path), "%s/%u", DHCP_LEASE_DIR, ifindex);
        f = fopen(path, "r");
        if (!f)
                return 0; // лизы ещё нет - DHCP не завершился или не используется

        while (fgets(buffer, sizeof(buffer), f)) {
                if (sscanf(buffer, "NETMASK=%d.%d.%d.%d", &a, &b, &c, &d) == 4) {
                        netmask[0]=a; netmask[1]=b; netmask[2]=c; netmask[3]=d;
                        have_netmask = 1;
                }
                if (sscanf(buffer, "ROUTER=%d.%d.%d.%d", &a, &b, &c, &d) == 4) {
                        gateway[0]=a; gateway[1]=b; gateway[2]=c; gateway[3]=d;
                        have_gateway = 1;
                }
        }
        fclose(f);
        return have_netmask && have_gateway;
}

int read_config(unsigned char * netmask, unsigned char * gateway, unsigned char * dst_ip)
{
        FILE * f;
        char buffer[128];
        int ip1, ip2, ip3, ip4, prefix;
        int retv = 0;
        int is_dhcp = 0;
        int have_addr = 0, have_gw = 0;

        // Обнуляем маску и шлюз перед чтением
        memset(netmask, 0, 4);
        memset(gateway, 0, 4);

        // Открываем новый файл systemd вместо INTERFACES_FILE
        f = fopen(SYSTEMD_NETWORK_FILE, "r");
        if(!f)
                return 0;

        // Читаем файл построчно — быстро и безопасно
        while(fgets(buffer, sizeof(buffer), f)) {
                // DHCP=ipv4 / DHCP=yes означает, что реальные netmask/gateway
                // нужно брать не из этого файла (тут их нет), а из лизы.
                if (strncmp(buffer, "DHCP=", 5) == 0 &&
                    strncmp(buffer + 5, "no", 2) != 0) {
                        is_dhcp = 1;
                }
                // Ищем строку с адресом и префиксом маски (например, Address=192.168.0.209/24)
                if (sscanf(buffer, "Address=%d.%d.%d.%d/%d", &ip1, &ip2, &ip3, &ip4, &prefix) == 5) {
                        prefix_to_netmask(prefix, netmask); // Переводим префикс обратно в 4 байта маски
                        have_addr = 1;
                }
                // Ищем строку со шлюзом (Gateway=192.168.0.1)
                if (sscanf(buffer, "Gateway=%d.%d.%d.%d", &ip1, &ip2, &ip3, &ip4) == 4) {
                        gateway[0] = ip1;
                        gateway[1] = ip2;
                        gateway[2] = ip3;
                        gateway[3] = ip4;
                        have_gw = 1;
                }
        }
        fclose(f);

        if (is_dhcp) {
                // Конфиг-файл существует и понятен (DHCP-режим) независимо
                // от того, успел ли DHCP уже отработать - поэтому retv=1
                // здесь не зависит от результата get_dhcp_lease(). Если
                // статический Address= тоже присутствует (наш дефолтный
                // шаблон) и лиза ещё не получена, netmask/gateway останутся
                // соответствовать этому статическому адресу либо нулю -
                // это нормальное переходное состояние.
                retv = 1;
                get_dhcp_lease(netmask, gateway);
        } else if (have_addr || have_gw) {
                retv = 1;
        }

        // Ниже логика чтения dst_ip_FILE остаётся без изменений, как в вашем коде
        dst_ip[0]=255; dst_ip[1]=255; dst_ip[2]=255; dst_ip[3]=255;
        f = fopen(dst_ip_FILE, "r");
        if(!f) return retv;
        if(fscanf(f, "%d.%d.%d.%d", &ip1, &ip2, &ip3, &ip4) == 4) {
                dst_ip[0]=ip1; dst_ip[1]=ip2; dst_ip[2]=ip3; dst_ip[3]=ip4;
        }
        fclose(f);
        return retv;
}


/**
* Проверка на то, что бы шлюз и устройство были в одной подсети
*
* Побайтовое сравнение вместо каста unsigned char* -> uint32_t*: старый
* вариант был UB по strict aliasing и мог упасть по невыровненному
* доступу (SIGBUS) в зависимости от компоновки devinst_proto.
**/
int check_ip_gw_mask(unsigned char * ip, unsigned char * netmask, unsigned char * gateway)
{
        for (int i = 0; i < 4; i++) {
                if ((ip[i] & netmask[i]) != (gateway[i] & netmask[i]))
                        return 0;
        }
        return 1;
}

/**
* Проверка ограничения доступа.
* Если файл ACCESS_FILE существует, то доступ ограничен
* Возвращает 1 если файл сущетсвует
**/
int check_access_disable(void)
{
        if( access( ACCESS_FILE, F_OK ) != -1 )
                return 1;
        else 
                return 0;
}

void write_config(unsigned char * ip, unsigned char * netmask, unsigned char * gateway, 
        unsigned char * dst_ip)
{
        FILE * f;
        int prefix = netmask_to_prefix(netmask);

        // Ручная настройка через утилиту (запрос по UDP) - это явный
        // static-запрос от инсталлятора, поэтому пишем чисто статический
        // конфиг без DHCP=. Если понадобится снова включить DHCP, для
        // этого есть config_reset() / отсутствие файла.
        f = fopen(SYSTEMD_NETWORK_FILE, "w"); // Открываем новый файл
        if (f != NULL) {
                fprintf(f, config_template, 
                        target_iface, 
                        ip[0], ip[1], ip[2], ip[3], prefix, // Передаем префикс вместо 4 чисел маски
                        gateway[0], gateway[1], gateway[2], gateway[3]
                );
                fclose(f);
        } else {
                pmesg(DEBUG_STATUS, "write_config: fopen(%s) failed\n", SYSTEMD_NETWORK_FILE);
        }

        f = fopen(dst_ip_FILE, "w");
        if (f != NULL) {
                fprintf(f, "%d.%d.%d.%d", dst_ip[0], dst_ip[1], dst_ip[2], dst_ip[3]);
                fclose(f);
        } else {
                pmesg(DEBUG_STATUS, "write_config: fopen(%s) failed\n", dst_ip_FILE);
        }
}

void get_ip(unsigned char * ipout, unsigned char * macout)
{
        struct ifaddrs * ifAddrStruct=NULL;
        struct ifaddrs * ifa=NULL;

        getifaddrs(&ifAddrStruct);

        for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
                if(ifa->ifa_addr != NULL && strcmp(ifa->ifa_name, target_iface)==0){
                        if (ifa->ifa_addr->sa_family==AF_INET) {
                                struct in_addr * tmpAddrPtr=NULL;
                                tmpAddrPtr=&((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
                                memcpy(ipout, tmpAddrPtr, 4);
                        }
                        else if(ifa->ifa_addr->sa_family==AF_PACKET){
                                struct sockaddr_ll *s = (struct sockaddr_ll*)ifa->ifa_addr;
                                // MAC-адрес - 6 байт, не 8. devinst_ip.mac
                                // объявлен как unsigned char mac[6], сразу
                                // за ним идёт ip[4] - копирование 8 байт
                                // затирало первые 2 байта IP-адреса.
                                memcpy(macout, s->sll_addr, 6);
                        }
                }
        }
        if (ifAddrStruct!=NULL) freeifaddrs(ifAddrStruct);
}

int open_udp_socket(void)
{
        int sd;
        int port = 10000;
                
        const int on=1;
        struct sockaddr_in addr;
                
        sd = socket(PF_INET, SOCK_DGRAM, 0);
        if ( sd < 0 )
                return 0;
        if ( setsockopt(sd, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on)) != 0 )
                return 0;
        bzero(&addr, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if ( bind(sd, (struct sockaddr*)&addr, sizeof(addr)) != 0 )
                return 0;
        return sd;
}

/**
* Отправка в сокет
**/
void socket_send(int sd, struct sockaddr* addr, char * data, int len)
{
        int port2 = 10001;
        struct sockaddr_in addr_br;

        // Обнуляем перед заполнением - раньше sin_zero оставался мусором
        // со стека (неинициализированная память).
        bzero(&addr_br, sizeof(addr_br));
        addr_br.sin_port = htons(port2);
        addr_br.sin_family = AF_INET;
        addr_br.sin_addr.s_addr = htonl(INADDR_BROADCAST);

        if(addr){
                if ( sendto(sd, data, len, 0, addr, sizeof(addr_br)) < 0 )
                        perror("sendto");
        }else{
                if ( sendto(sd, data, len, 0, (struct sockaddr*)&addr_br, sizeof(addr_br)) < 0 )
                        perror("sendto");
        }
}


int socket_receive(int sd)
{
        char buffer[1024];
        int recv_size;
        struct sockaddr_in addr;
        devinst_proto proto;
        devinst_proto out_data;
        socklen_t len = sizeof(addr);
        char zero_mac[]={0,0,0,0,0,0};

        memset(out_data.data, 0x00, sizeof(out_data.data));
        recv_size=recvfrom(sd, buffer, sizeof(buffer), 0, (struct sockaddr*)&addr, &len);

        // Критично: recv_size мог быть 0 (пустой UDP-пакет) или -1 (ошибка).
        // Старая проверка "recv_size >= sizeof(out_data.data)+1" такие
        // случаи не отсекала для recv_size==0, а следующая строка считала
        // memcpy(..., recv_size-1) - при recv_size==0 это (size_t)-1, т.е.
        // гигантский memcpy и гарантированный краш. Пустой UDP-пакет на
        // порт 10000 может прислать кто угодно в сети - удалённый DoS.
        if (recv_size <= 0) {
                return 0;
        }
        if (recv_size >= (int)sizeof(out_data.data)+1) {
                return 0;
        }

        memcpy(proto.data, buffer+1, recv_size-1);
        switch(buffer[0]){
        case DEVINST_ID:
                break;
        case DEVINST_IP:
                get_ip(out_data.ip.ip, out_data.ip.mac);
                read_config(out_data.ip.mask, out_data.ip.gw, out_data.ip.dst_ip);
                if(memcmp(proto.ip.mac, zero_mac, 6)==0){
                        pmesg(DEBUG_INFO, "DEVINST_IP\r\n");
                        buffer[0] = DEVINST_IP;
                        memcpy(buffer+1, out_data.data, sizeof(devinst_ip));
                        socket_send(sd, 0, buffer, sizeof(devinst_ip)+1);
                }
                else if(memcmp(proto.ip.mac, out_data.ip.mac,6)==0){
                        pmesg(DEBUG_INFO, "DEVINST_IP\r\n");
                        pmesg(DEBUG_INFO, "%d %d %d %d\n", proto.ip.mask[0], proto.ip.mask[1], proto.ip.mask[2], proto.ip.mask[3]);
                        if((proto.ip.mask[0]==0)&&(proto.ip.mask[1]==0)
                                &&(proto.ip.mask[2]==0)&&(proto.ip.mask[3]==0)){
                                
                                proto.ip.mask[0]=255;
                                proto.ip.mask[1]=255;
                                proto.ip.mask[2]=255;
                        }
                        if((proto.ip.gw[0]==0)&&(proto.ip.gw[1]==0)
                                &&(proto.ip.gw[2]==0)&&(proto.ip.gw[3]==0)){
                                
                                proto.ip.gw[0]=proto.ip.ip[0];
                                proto.ip.gw[1]=proto.ip.ip[1];
                                proto.ip.gw[2]=proto.ip.ip[2];
                                proto.ip.gw[3]=1;
                        }
                        if(check_ip_gw_mask(proto.ip.ip, proto.ip.mask, proto.ip.gw)
                                &&(check_access_disable()==0)){
                                write_config(proto.ip.ip, proto.ip.mask, proto.ip.gw, proto.ip.dst_ip);
                                system("networkctl reload");       // Перечитать файлы конфигурации
                                system("networkctl reconfigure eth0"); // Применить к eth0
                                system("sync");
                                
                                return 1;
                        }
                }
                break;
        }
        return 0;
}

static int parse_opt(int argc, char *argv[ ])
{
        int c;
        int errflg=0;
        extern char *optarg;
        extern int optind, optopt;
        while ((c = getopt(argc, argv, "d:")) != -1) {
                switch(c) {
                case 'd':
                        sscanf(optarg, "%d", &dflg);
                        break;
                case '?':
                        fprintf(stderr,
                                "Unrecognized option: -%c\n", optopt);
                        errflg++;
                }
        }
        return errflg;
}

void send_devinst(int sd)
{
        devinst_proto out_data;
        char buffer[1024];

        memset(out_data.data, 0x00, sizeof(out_data.data));
        get_ip(out_data.ip.ip, out_data.ip.mac);
        read_config(out_data.ip.mask, out_data.ip.gw, out_data.ip.dst_ip);
        buffer[0] = DEVINST_IP;
        memcpy(buffer+1, out_data.data, sizeof(devinst_ip));
                socket_send(sd, 0, buffer, sizeof(devinst_ip)+1);
}

void config_reset()
{
        FILE * f;

        f = fopen(SYSTEMD_NETWORK_FILE, "w");
        // ИСПРАВЛЕНО: раньше результат fopen не проверялся - при недоступной
        // для записи файловой системе (read-only rootfs, отсутствующая
        // директория и т.п.) следующий fwrite/fclose работал бы с NULL и
        // приложение падало бы по SIGSEGV.
        if (f == NULL) {
                pmesg(DEBUG_STATUS, "config_reset: fopen(%s) failed\n", SYSTEMD_NETWORK_FILE);
                return;
        }

        fwrite(config_default, strlen(config_default), 1, f);
        fclose(f);
        system("networkctl reload");
        system("networkctl reconfigure eth0");
        system("sync");
}

void check_config()
{
        int ret;
        devinst_proto out_data;
        ret = read_config(out_data.ip.mask, out_data.ip.gw, out_data.ip.dst_ip);
        if(!ret)
                config_reset();

}

/**
* Ждёт до timeout_ms миллисекунд, пока target_iface не получит реальный
* IPv4-адрес (не 0.0.0.0). Актуально при DHCP=ipv4 без ещё полученной
* лизы: первое объявление send_devinst() иначе может уйти с пустым IP.
* Ограничено по времени, чтобы не блокировать демон навсегда, если
* DHCP-сервера в сети действительно нет (тогда используется static
* fallback-адрес из config_default, который появляется почти сразу).
**/
static int wait_for_ip(int timeout_ms)
{
        unsigned char ip[4] = {0,0,0,0};
        unsigned char mac[8] = {0,0,0,0,0,0,0,0};
        int waited = 0;
        const int step_ms = 200;

        while (waited < timeout_ms) {
                get_ip(ip, mac);
                if (ip[0] || ip[1] || ip[2] || ip[3])
                        return 1;
                usleep(step_ms * 1000);
                waited += step_ms;
        }
        return 0;
}

int main(int argc, char *argv[ ])
{
        int sd;
        printf("profitt-di application\n");
        if (parse_opt(argc, argv)) return 1;
        check_config();
        wait_for_ip(3000); // до 3 секунд подождать реальный адрес (DHCP/static)

        sd = open_udp_socket();
        send_devinst(sd);
        while(1){
                if (socket_receive(sd) == 1) {
                        close(sd);              // Закрываем старый сокет
                        sleep(1);               // Даём секунду systemd-networkd поднять eth0
                        sd = open_udp_socket();  // Открываем сокет заново
                        send_devinst(sd);       // Отправляем в сеть анонс с новым IP
                }
        }
        return 0;
}